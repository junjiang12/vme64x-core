#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdint.h>

struct cRIO_EEPROM {
  uint16_t EEPROM_addressing_mode;
  uint16_t start_sentinel;
  uint16_t class_id;
  uint16_t product_id;
  uint16_t vendor_id;
  uint16_t module_model_code;
  uint32_t extended_serial_no;
  uint32_t serial_no;
  uint16_t configuration_version;
  uint16_t module_descriptor_address;
  uint16_t reserved[12];
  
  uint16_t cartridge_desc_size;
  uint16_t cartridge_revision;
  uint16_t min_spi_clock_period;
  uint16_t suffix_conf_section_address;
  uint16_t module_name_length;
  uint16_t *cartridge_name;
  uint16_t crc;
  uint16_t end_sentinel;
};
  

#define CRIO_EE_HEADER_SIZE 48
#define CRIO_EE_MODDESC_MIN_SIZE 10

uint32_t crc_16(uint32_t crc, uint32_t data)
{
  int i;
  uint32_t old_crc, new_crc, fb;

  old_crc = crc;
  for (i = 0; i < 16; i++)
    {
      new_crc = (old_crc << 1) & 0x0ffff;
      new_crc ^= (old_crc & 0x08000);
      fb = ((data & 0x08000) ^ (old_crc & 0x08000)) >> 15;
      new_crc ^= (fb << 2);
      new_crc |= fb;
      old_crc = new_crc;
      data <<= 1;
    }

  return new_crc;
}

void calc_crc(struct cRIO_EEPROM *crio)
{
  int i;
  uint32_t crc;

  crc = 0x0FFFF;
  crc = crc_16(crc, crio->EEPROM_addressing_mode);
  crc = crc_16(crc, crio->start_sentinel);
  crc = crc_16(crc, crio->class_id);
  crc = crc_16(crc, crio->product_id);
  crc = crc_16(crc, crio->vendor_id);
  crc = crc_16(crc, crio->module_model_code);
  crc = crc_16(crc, crio->extended_serial_no >> 16);
  crc = crc_16(crc, crio->extended_serial_no);
  crc = crc_16(crc, crio->serial_no >> 16);
  crc = crc_16(crc, crio->serial_no);
  crc = crc_16(crc, crio->configuration_version);
  crc = crc_16(crc, crio->module_descriptor_address);
  for (i = 0; i < 12; i++)
    crc = crc_16(crc, crio->reserved[i]);
  crc = crc_16(crc, crio->cartridge_desc_size);
  crc = crc_16(crc, crio->cartridge_revision);
  crc = crc_16(crc, crio->min_spi_clock_period);
  crc = crc_16(crc, crio->suffix_conf_section_address);
  crc = crc_16(crc, crio->module_name_length);
  for (i = 0; i < crio->module_name_length / 2; i++)
    crc = crc_16(crc, crio->cartridge_name[i]);
  crio->crc = crc;
}

#define UINT16_HI(d) ((d >> 8) & 0x00ff)
#define UINT16_LO(d) (d & 0x00ff)
#define UINT32_HIHI(d) ((d >> 24) & 0x00ff)
#define UINT32_HI(d) ((d >> 16) & 0x00ff)
#define UINT32_LO(d) ((d >> 8) & 0x00ff)
#define UINT32_LOLO(d) (d & 0x00ff)

int compose_EEPROM(struct cRIO_EEPROM *crio, char *EEPROM)
{
  char *p = EEPROM;
  int i;

  *(p++) = UINT16_HI(crio->EEPROM_addressing_mode);
  *(p++) = UINT16_LO(crio->EEPROM_addressing_mode);
  *(p++) = UINT16_HI(crio->start_sentinel);
  *(p++) = UINT16_LO(crio->start_sentinel);
  *(p++) = UINT16_HI(crio->class_id);
  *(p++) = UINT16_LO(crio->class_id);
  *(p++) = UINT16_HI(crio->product_id);
  *(p++) = UINT16_LO(crio->product_id);
  *(p++) = UINT16_HI(crio->vendor_id);
  *(p++) = UINT16_LO(crio->vendor_id);
  *(p++) = UINT16_HI(crio->module_model_code);
  *(p++) = UINT16_LO(crio->module_model_code);
  *(p++) = UINT32_HIHI(crio->extended_serial_no);
  *(p++) = UINT32_HI(crio->extended_serial_no);
  *(p++) = UINT32_LO(crio->extended_serial_no);
  *(p++) = UINT32_LOLO(crio->extended_serial_no);
  *(p++) = UINT32_HIHI(crio->serial_no);
  *(p++) = UINT32_HI(crio->serial_no);
  *(p++) = UINT32_LO(crio->serial_no);
  *(p++) = UINT32_LOLO(crio->serial_no);
  *(p++) = UINT16_HI(crio->configuration_version);
  *(p++) = UINT16_LO(crio->configuration_version);
  *(p++) = UINT16_HI(crio->module_descriptor_address);
  *(p++) = UINT16_LO(crio->module_descriptor_address);
  for (i = 0; i < 12; i++)
    {
      *(p++) = UINT16_HI(crio->reserved[i]);
      *(p++) = UINT16_LO(crio->reserved[i]);
    }

  *(p++) = UINT16_HI(crio->cartridge_desc_size);
  *(p++) = UINT16_LO(crio->cartridge_desc_size);
  *(p++) = UINT16_HI(crio->cartridge_revision);
  *(p++) = UINT16_LO(crio->cartridge_revision);
  *(p++) = UINT16_HI(crio->min_spi_clock_period);
  *(p++) = UINT16_LO(crio->min_spi_clock_period);
  *(p++) = UINT16_HI(crio->suffix_conf_section_address);
  *(p++) = UINT16_LO(crio->suffix_conf_section_address);
  *(p++) = UINT16_HI(crio->module_name_length);
  *(p++) = UINT16_LO(crio->module_name_length);
  for (i = 0; i < crio->module_name_length / 2; i++)
    {
      *(p++) = UINT16_HI(crio->cartridge_name[i]);
      *(p++) = UINT16_LO(crio->cartridge_name[i]);
    }
  *(p++) = UINT16_HI(crio->crc);
  *(p++) = UINT16_LO(crio->crc);
  *(p++) = UINT16_HI(crio->end_sentinel);
  *(p++) = UINT16_LO(crio->end_sentinel);
  
  return ((int) p - (int) EEPROM);
}

void write_Srec(char *p, int size)
{
  int addr, i, len, dt, cs;

  addr = 0x08000000;
  while (size)
    {
      if (size > 32)
	{
	  size -= 32;
	  len = 32;
	}
      else
	{
	  len = size;
	  size = 0;
	}
      cs = 0;
      printf("S3%02X%08X", len+5, addr);
      cs += len+5;
      cs += (addr >> 24);
      cs += (addr >> 16);
      cs += (addr >> 8);
      cs += (addr);
      addr += len;
      for (; len; len--)
	{
	  dt = *(p++) & 0x00ff;
	  cs += dt;
	  printf("%02X", dt);
	}
      printf("%02X\n", (~cs) & 0x00ff);
    }
}

main()
{
  struct cRIO_EEPROM crio;
  int i, eesize;
  uint16_t cart_name[] = {
    0x0063, /* Module name 'c' */
    0x0052, /* Module name 'R' */
    0x0049, /* Module name 'I' */
    0x004F, /* Module name 'O' */
    0x002D, /* Module name '-' */
    0x0045, /* Module name 'E' */
    0x0056, /* Module name 'V' */
    0x0052, /* Module name 'R' */
    0x0033, /* Module name '3' */
    0x0030, /* Module name '0' */
    0x0030, /* Module name '0' */
    0};
  char EEPROM[2048];

  /* 1-byte EEPROM, 32-byte page, 2048 bytes total */
  crio.EEPROM_addressing_mode = 0x4B00;
  crio.start_sentinel = 0x3A29;
  /* Class ID, no compatible module exist */
  crio.class_id = 0x0000;
  /* EVR-300 */
  crio.product_id = 0x112C;
  crio.vendor_id = 0x1A3E;
  crio.module_model_code = 0x0300;
  crio.extended_serial_no = 0;
  crio.serial_no = 0;
  crio.configuration_version = 0x0101;
  crio.reserved[12];
  
  crio.cartridge_revision = 0x0101;
  crio.min_spi_clock_period = 0x0000;
  for (i = 0; cart_name[i]; i++);
  crio.module_name_length = i*2;
  crio.cartridge_name = cart_name;
  crio.end_sentinel = 0xC5D7;

  crio.module_descriptor_address = 
    CRIO_EE_HEADER_SIZE;

  crio.cartridge_desc_size =
    CRIO_EE_MODDESC_MIN_SIZE +
    crio.module_name_length;

  crio.suffix_conf_section_address = 
    crio.module_descriptor_address +
    crio.cartridge_desc_size;

  calc_crc(&crio);
  eesize = compose_EEPROM(&crio, EEPROM);

  write_Srec(EEPROM, eesize);
}

/*
#define BOOT_FROM_FLASH          1
*/

#define uint32_t unsigned int

#define UART_BASE                (0x80006000)
#define UART_DATA                (0x0000)
#define UART_IRQEN               (0x0004)
#define UART_IRQSTAT             (0x0008)
#define UART_LCR                 (0x000C)
#define UART_LCR_DR              (0x0001)
#define UART_LCR_OE              (0x0002)
#define UART_LCR_PE              (0x0004)
#define UART_LCR_FE              (0x0008)
#define UART_LCR_BI              (0x0010)
#define UART_LCR_THRE            (0x0020)
#define UART_LCR_TEMT            (0x0040)
#define UART_MODEMCTRL           (0x0010)
#define UART_LSR                 (0x0014)
#define UART_LSR_DR              (0x0001)
#define UART_LSR_THRE            (0x0020)
#define UART_MODEMSTAT           (0x0018)
#define UART_BAUDRATE            (0x001C)

#define SPI_BASE                 (0x8000C000)
#define SPI_RXDATA               (0x0000)
#define SPI_TXDATA               (0x0004)
#define SPI_STATUS               (0x0008)
#define SPI_STATUS_E             (0x0100)
#define SPI_STATUS_RRDY          (0x0080)
#define SPI_STATUS_TRDY          (0x0040)
#define SPI_STATUS_TMT           (0x0020)
#define SPI_STATUS_TOE           (0x0010)
#define SPI_STATUS_ROE           (0x0008)
#define SPI_CONTROL              (0x000C)
#define SPI_CONTROL_SSO          (0x0400)
#define SPI_CONTROL_IE           (0x0100)
#define SPI_CONTROL_IRRDY        (0x0080)
#define SPI_CONTROL_ITRDY        (0x0040)
#define SPI_CONTROL_ITOE         (0x0010)
#define SPI_CONTROL_IROE         (0x0008)
#define SPI_SLAVESELECT          (0x0010)

#define SPI_SLAVE_ADDRESS_NONE   (0x00)
#define SPI_SLAVE_ADDRESS_EEPROM (0x04)
#define SPI_SLAVE_ADDRESS_FLCONF (0x01)
#define SPI_SLAVE_ADDRESS_FLSW   (0x02)

#define M25P32_BOOT_BASE         (0x08000000)
#define M25P32_BOOT_SECTORS      (0x0010)

#define M25P32_SECTOR_SIZE       (0x10000)
#define M25P32_PAGE_SIZE         (0x00100)
#define M25P32_SECTORS           (64)
#define M25P32_WEL               (0x02)
#define M25P32_WIP               (0x01)
#define M25P32_WREN              (0x06)
#define M25P32_WRDI              (0x04)
#define M25P32_RDID              (0x9F)
#define M25P32_RDSR              (0x05)
#define M25P32_WRSR              (0x01)
#define M25P32_READ              (0x03)
#define M25P32_FAST_READ         (0x0B)
#define M25P32_PP                (0x02)
#define M25P32_SE                (0xD8)
#define M25P32_BE                (0xC7)
#define M25P32_DP                (0xB9)
#define M25P32_RES               (0xAB)

#define M95160_BYTES             (2048)
#define M95160_WEL               (0x02)
#define M95160_WIP               (0x01)
#define M95160_WREN              (0x06)
#define M95160_WRDI              (0x04)
#define M95160_RDSR              (0x05)
#define M95160_WRSR              (0x01)
#define M95160_READ              (0x03)
#define M95160_WRITE             (0x02)

#define GPIO_BASE                (0x80004000)
#define GPIO_DATA                (0x0000)
#define GPIO_TRI                 (0x0004)
#define GPIO_IDSEL_PULLUP        (0x01)

char help[] = 
  "\r\nLM32 Help\r\n"
  "B       Bit swap (bytewise) 8 Mbytes at X\r\n"
  "D       Dump Memory at address X\r\n"
  "EC  sr  Write EEPROM Status Register\r\n"
  "ER      Read EEPROM data to memory address X\r\n"
  "ES      Read EEPROM Status Register\r\n"
  "EW      Write EEPROM data starting from memory address X\r\n"
  "FnB     Flash n Bulk Erase\r\n"
  "FnC sr  Flash n Write Status Register\r\n"
  "FnS s   Flash n Erase Sector s\r\n"
  "FnQ     Query Flash n Status\r\n"
  "FnR     Read Flash n to memory at address X\r\n"
  "FnV     Verify Flash n with memory at address X\r\n"
  "FnW s m Write m bytes to Flash n Sector s from memory address X\r\n"
  "G       Start program execution at address X\r\n"
  "I   d   IDSEL pullup state d (0/1), also controls EEPROM access\r\n"
  "L   off Load S-records (32-bit address)\r\n"
  "M       Modify memory at address X\r\n"
  "SS  ss  SPI Slave select\r\n"
  "SW  d   SPI Write/Read\r\n"
  "V   off Verify S-records\r\n"
  "X   x   Set address X\r\n";

void uart_init()
{
  uint32_t *uart_lcr = (uint32_t *) (UART_BASE + UART_LCR);

  /* 8 data bits, no parity */
  *uart_lcr = 0x0003;
}

void uart_txd(char txd)
{
  uint32_t *uart_lsr = (uint32_t *) (UART_BASE + UART_LSR);
  uint32_t *uart_data = (uint32_t *) (UART_BASE + UART_DATA);

  /* Wait for THR empty */
  while (!((*uart_lsr) & UART_LSR_THRE));

  *uart_data = txd;
}

void uart_puts(char *s)
{
  while (*s)
    uart_txd(*(s++));
}

void uart_write_u32(uint32_t val)
{
  int i;
  char c;

  for (i = 28; i >= 0; i-=4)
    {
      c = ((val >> i) & 0x0f) + '0';
      if (c > '9')
	c += 'A' - '0' - 10;
      uart_txd(c);
    }
}

char uart_rxd()
{
  uint32_t *uart_lsr = (uint32_t *) (UART_BASE + UART_LSR);
  uint32_t *uart_data = (uint32_t *) (UART_BASE + UART_DATA);

  /* Wait for receiver data ready */
  while (!((*uart_lsr) & UART_LSR_DR));

  return (char) *uart_data;
}

char uart_rxdU()
{
  char c;

  c = uart_rxd();
  if (c >= 'a' && c < 'z')
    c += 'A' - 'a';
  uart_txd(c);

  return c;
}

int uart_is_rxready()
{
  uint32_t *uart_lsr = (uint32_t *) (UART_BASE + UART_LSR);
  
  /* return 0 when receiver not ready */
  return ((*uart_lsr) & UART_LSR_DR);
}

int uart_read_u8(uint32_t *val)
{
  int i = 0;
  uint32_t ret = 0;
  char c;

  for (i = 0; i < 2; i++)
    {
      c = uart_rxd();
      if (c == '\r' || c == '\n')
	break;
      if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F'))
	{
	  c -= '0';
	  if (c > 9)
	    c -= 'A' - '0' - 10;
	  ret <<= 4;
	  ret += c;
	}
      else
	return -1;
    }

  *val = ret;
  return 0;
}

int uart_read_su8(uint32_t *val, uint32_t *cs)
{
  uint32_t ret;

  ret = uart_read_u8(val);
  if (cs)
    *cs = *cs + *val;
  return ret;
}

int uart_read_u32(uint32_t *val)
{
  int i = 0;
  uint32_t ret = 0;
  char c;

  for (i = 0; i < 8; i++)
    {
      c = uart_rxdU();
      if (c == '\r' || c == '\n')
	break;
      if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F'))
	{
	  c -= '0';
	  if (c > 9)
	    c -= 'A' - '0' - 10;
	  ret <<= 4;
	  ret += c;
	}
      else
	return -1;
    }

  *val = ret;
  return 0;
}

int uart_are_you_sure()
{
  int c;

  uart_puts("\r\nAre you sure (Y/N)? ");
  c = uart_rxdU();
  if (c == 'Y')
    return 1;
  return 0;
}

void spi_init()
{
  uint32_t *spic = (uint32_t *) (SPI_BASE + SPI_CONTROL);
  uint32_t *spistat = (uint32_t *) (SPI_BASE + SPI_STATUS);

  *spic = SPI_CONTROL_SSO;
  /* Clear status register */
  *spistat = 0;
}

void spi_slave_select(int slave)
{
  uint32_t *ss = (uint32_t *) (SPI_BASE + SPI_SLAVESELECT);

  *ss = slave;
}

uint32_t spi_rw(uint32_t txd)
{
  uint32_t *spistat = (uint32_t *) (SPI_BASE + SPI_STATUS);
  uint32_t *spitxd = (uint32_t *) (SPI_BASE + SPI_TXDATA);
  uint32_t *spirxd = (uint32_t *) (SPI_BASE + SPI_RXDATA);
  int i;

#ifdef DEBUG_SPI
  uart_write_u32(*spistat);
  uart_txd(',');
#endif
  /* Wait for transmitter ready */
  for (i = 1000000; i; i--)
    if ((*spistat) & SPI_STATUS_TRDY)
      break;

  if (!i)
    return -1;
  
  /* Write new data */
  *spitxd = txd;
  
#ifdef DEBUG_SPI
  uart_write_u32(*spistat);
  uart_txd(',');
#endif
  /* Wait for receiver ready/transmit shift register empty */
  for (i = 10000000; i; i--)
    if ((*spistat) & SPI_STATUS_TMT)
      break;

#ifdef DEBUG_SPI
  uart_write_u32(*spistat);
  uart_txd(',');
#endif

  if (!i)
    return -2;

  return *spirxd;
}

uint32_t spi_mem_read_status(uint32_t sel)
{
  uint32_t d;

  spi_slave_select(sel);
  spi_rw(M95160_RDSR);
  d = spi_rw(0);
  spi_slave_select(SPI_SLAVE_ADDRESS_NONE);

  return d;
}

uint32_t spi_mem_write_enable(uint32_t sel)
{
  uint32_t i,d;

  spi_slave_select(sel);
  spi_rw(M95160_WREN);
  spi_slave_select(SPI_SLAVE_ADDRESS_NONE);
  for (i = 100; i; i--);
  d = spi_mem_read_status(sel) & M95160_WEL;
  if (!d)
    uart_txd('#');
  for (i = 100; i; i--);
  return d;
}

uint32_t cRIO_IDSEL_pullup_enable(int enable)
{
  uint32_t *gpio_data = (uint32_t *) (GPIO_BASE + GPIO_DATA);
  uint32_t out;
 
  out = (*gpio_data) & (~GPIO_IDSEL_PULLUP);
  if (enable)
    out |= GPIO_IDSEL_PULLUP;
  *gpio_data = out;

  return (*gpio_data);
}

int main()
{
  char c;
  uint32_t *x;
  uint32_t d;
  int i, j;

  x = 0;

  uart_init();
  spi_init();

  uart_puts("Press any key to enter monitor.\r\n");

  {
    char *pt = (char *) M25P32_BOOT_BASE;
    void (*callpt)(void);

    spi_slave_select(SPI_SLAVE_ADDRESS_FLSW);
    spi_rw(M25P32_FAST_READ);
    spi_rw(0);
    spi_rw(0);
    spi_rw(0);
    spi_rw(0);
    for (i = 0; i < M25P32_BOOT_SECTORS; i++)
      {
	for (j = M25P32_SECTOR_SIZE; j; j--)
	  *(pt++) = spi_rw(0);
      }

    /* Go start program copied from flash to SDRAM
       when no char from uart */
    if (!uart_is_rxready())
      {
	/* Go at address X */
	callpt = (void (*) ()) M25P32_BOOT_BASE;
#ifdef BOOT_FROM_FLASH
	callpt();
#endif
      }    
  }

  /*
  cRIO_IDSEL_pullup_enable(1);
  */

  while (1)
    {
      uart_puts("\r\n");
      uart_write_u32((unsigned int) x);
      uart_puts("> ");
      c = uart_rxdU();
      switch(c)
	{
	case 'B':
	  /* Bit swap memory (M25P32_SECTOR_SIZE * M25P32_SECTORS) @ X */
	  {
	    uint32_t mask, swapped;
	    uint32_t *pt = x;

	    for (i = M25P32_SECTOR_SIZE * M25P32_SECTORS / 4; i; i--)
	      {
		d = *pt;
		swapped = 0;
		mask = 0x01010101;
		for (j = 7; j > 0; j-=2)
		  {
		    swapped |= (d & mask) << j;
		    mask <<= 1;
		  }
		for (j = 1; j < 8; j+=2)
		  {
		    swapped |= (d & mask) >> j;
		    mask <<= 1;
		  }
		*(pt++) = swapped;
	      }
	  }
	  break;
	case 'D':
	  for (j = 0; j < 8; j++)
	    {
	      uart_puts("\r\n");
	      for (i = 0; i < 4; i++)
		{
		  uart_write_u32(*x++);
		  uart_txd(' ');
		}
	    }
	  break;
	case 'E':
	  {
	    /* EEPROM */
	    c = uart_rxdU();
	    switch (c)
	      {
	      case 'C':
		/* Write Status register */
		uart_txd(' ');
		if (!uart_read_u32(&d))
		  {
		    spi_mem_write_enable(SPI_SLAVE_ADDRESS_EEPROM);
		    spi_slave_select(SPI_SLAVE_ADDRESS_EEPROM);
		    spi_rw(M95160_WRSR);
		    spi_rw(d);
		    spi_slave_select(SPI_SLAVE_ADDRESS_NONE);
		  }
		break;
	      case 'R':
		{
		  char *pt = (char *) x;

		  /* Read EEPROM array to address X */
		  spi_slave_select(SPI_SLAVE_ADDRESS_EEPROM);
		  spi_rw(M95160_READ);
		  spi_rw(0x00);
		  spi_rw(0x00);
		  for (i = M95160_BYTES; i; i--)
		    {
		      *(pt++) = spi_rw(0);
		    } 
		  spi_slave_select(SPI_SLAVE_ADDRESS_NONE);
		}
		break;
	      case 'S':
		/* Read Status register */
		uart_txd(' ');
		d = spi_mem_read_status(SPI_SLAVE_ADDRESS_EEPROM);
		uart_write_u32(d);
		break;
	      case 'W':
		{
		  char *pt = (char *) x;

		  /* Write EEPROM array from address X */
		  for (i = 0; i < M95160_BYTES; i += 32)
		    {
		      spi_mem_write_enable(SPI_SLAVE_ADDRESS_EEPROM);
		      spi_slave_select(SPI_SLAVE_ADDRESS_EEPROM);
		      spi_rw(M95160_WRITE);
		      spi_rw(i >> 8);
		      spi_rw(i);
		      for (j = 32; j; j--)
			spi_rw(*(pt++));
		      spi_slave_select(SPI_SLAVE_ADDRESS_NONE);
		      /* Wait for write complete */
		      for (j = 100000; j; j--)
			{
			  d = spi_mem_read_status(SPI_SLAVE_ADDRESS_EEPROM);
			  if (!(d & M95160_WIP))
			    {
			      uart_txd('.');
			      break;
			    }
			}
		    } 
		}
		break;
	      }
	  }
	  break;
	case 'F':
	  {
	    int fl = SPI_SLAVE_ADDRESS_NONE; 
	    
	    /* Flash commands */
	    c = uart_rxdU();
	    if (c == '1')
	      fl = SPI_SLAVE_ADDRESS_FLCONF;
	    if (c == '2')
	      fl = SPI_SLAVE_ADDRESS_FLSW;
	    if (fl != SPI_SLAVE_ADDRESS_NONE)
	      {
		c = uart_rxdU();
		switch (c)
		  {
		  case 'B':
		    if (uart_are_you_sure())
		      {
			if(spi_mem_write_enable(fl))
			  {
			    spi_slave_select(fl);
			    spi_rw(M25P32_BE);
			    spi_slave_select(SPI_SLAVE_ADDRESS_NONE);
			    for (i = 1000; i; i--)
			      {
				for (j = 1000; j; j--)
				  {
				    d = spi_mem_read_status(fl);
				    if (!(d & M25P32_WIP))
				      break;
				  }
				if (!(d & M25P32_WIP))
				  break;
				uart_txd('.');
			      }
			  }
		      }
		    break;
		  case 'C':
		    /* Write Status register */
		    uart_txd(' ');
		    if (!uart_read_u32(&d))
		      {
			if(spi_mem_write_enable(fl))
			  {
			    spi_slave_select(fl);
			    spi_rw(M25P32_WRSR);
			    spi_rw(d);
			    spi_slave_select(SPI_SLAVE_ADDRESS_NONE);
			  }
		      }
		    break;
		  case 'R':
		    {
		      char *pt = (char *) x;
		      uart_txd('\n');
		      spi_slave_select(fl);
		      spi_rw(M25P32_FAST_READ);
		      spi_rw(0);
		      spi_rw(0);
		      spi_rw(0);
		      spi_rw(0);
		      for (i = 0; i < M25P32_SECTORS; i++)
			{
			  for (j = M25P32_SECTOR_SIZE; j; j--)
			    *(pt++) = spi_rw(0);
			  uart_txd('\r');
			  uart_write_u32(i << M25P32_SECTOR_SIZE);
			}
		    }
		    break;
		  case 'Q':
		    {
		      uart_puts("\r\nStatus ");
		      uart_write_u32(spi_mem_read_status(fl));
		      spi_slave_select(fl);
		      spi_rw(M25P32_FAST_READ);
		      spi_rw(0);
		      spi_rw(0);
		      spi_rw(0);
		      spi_rw(0);
		      for (i = 0; i < M25P32_SECTORS; i++)
			{
			  int empty = 1;
			  for (j = M25P32_SECTOR_SIZE; j; j--)
			    if (spi_rw(0) != 0x00ff)
			      empty = 0;
			  uart_puts("\r\nSector ");
			  uart_write_u32(i * M25P32_SECTOR_SIZE);
			  if (!empty)
			    uart_puts(" not");
			  uart_puts(" erased.");
			}
		    }
		    break;
		  case 'S':
		    uart_txd(' ');
		    if (!uart_read_u32(&d))
		      {
			if ((d & (M25P32_SECTOR_SIZE-1)) == 0)
			  if (uart_are_you_sure())
			    {
			      if(spi_mem_write_enable(fl))
				{
				  spi_slave_select(fl);
				  spi_rw(M25P32_SE);
				  spi_rw(d >> 16);
				  spi_rw(d >> 8);
				  spi_rw(d);
				  spi_slave_select(SPI_SLAVE_ADDRESS_NONE);
				  for (i = 1000; i; i--)
				    {
				      for (j = 1000; j; j--)
					{
					  d = spi_mem_read_status(fl);
					  if (!(d & M25P32_WIP))
					    break;
					}
				      if (!(d & M25P32_WIP))
					break;
				      uart_txd('.');
				    }
				}
			    }
		      }
		    break;
		  case 'V':
		    {
		      int errs = 0;

		      char *pt = (char *) x;
		      uart_txd('\n');
		      spi_slave_select(fl);
		      spi_rw(M25P32_FAST_READ);
		      spi_rw(0);
		      spi_rw(0);
		      spi_rw(0);
		      spi_rw(0);
		      for (i = 0; i < M25P32_SECTORS; i++)
			{
			  for (j = M25P32_SECTOR_SIZE; j; j--)
			    if (*(pt++) != (char) spi_rw(0))
			      {
				errs++;
				if (errs < 10)
				  {
				    uart_puts("\r\nError at address ");
				    uart_write_u32((unsigned int) pt-1);
				    uart_puts("\r\n");
				  }
			      }
			  uart_txd('\r');
			  uart_write_u32(i << M25P32_SECTOR_SIZE);
			}
		      uart_write_u32(errs);
		      uart_puts(" Errors");
		    }
		    break;
		  case 'W':
		    {
		      uint32_t sector, bytes;
		      char *pt = (char *) x;
	      
		      uart_txd(' ');
		      if (uart_read_u32(&sector))
			break;
		      if (sector & (M25P32_SECTOR_SIZE-1) != 0)
			break;
		      uart_txd(' ');
		      if (uart_read_u32(&bytes))
			break;
		      for (i = 0; i < bytes; i += M25P32_PAGE_SIZE)
			{
			  if (!(i & (M25P32_SECTOR_SIZE-1)))
			    uart_puts("\r\n");
			  if(spi_mem_write_enable(fl))
			    {
			      spi_slave_select(fl);
			      spi_rw(M25P32_PP);
			      spi_rw((sector + i) >> 16);
			      spi_rw((sector + i) >> 8);
			      spi_rw((sector + i));
			      for (j = 0; j < M25P32_PAGE_SIZE; j++)
				spi_rw(*(pt++));
			      spi_slave_select(SPI_SLAVE_ADDRESS_NONE);
			      for (j = 10000; j; j--)
				{
				  d = spi_mem_read_status(fl);
				  if (!(d & M25P32_WIP))
				    break;
				}
			      if (j)
				uart_txd('.');
			      else
				uart_txd('*');
			    }
			}
		    break;
		    }
		  }
	      }
	  }
	  break;
	case 'G':
	  {
	    void (*callpt)(void);
	    /* Go at address X */
	    callpt = (void (*) ()) x;
	    callpt();
	  }
	  break;
	case 'H':
	case '?':
	  uart_puts(help);
	  break;
	case 'I':
	  uart_txd(' ');
	  c = uart_rxd();
	  if (c == '0' || c == '1')
	    {
	      uart_txd(' ');
	      uart_write_u32(cRIO_IDSEL_pullup_enable(c - '0'));
	    }
	  break;
	case 'L':
	  {
	    uint32_t records = 0;
	    uint32_t cs_errs = 0;
	    uint32_t offset;

	    uart_txd(' ');
	    if(uart_read_u32(&offset))
	      break;
	    uart_puts("\r\nLoading S-records... '@' to exit.\r\n");
	    do
	      {
		c = uart_rxd();
		if (c == 'S')
		  {
		    uint32_t cs;
		    uint32_t dt;
		    uint32_t len;
		    uint32_t addr;
		    char *pt;

		    c = uart_rxd();
		    /* Read number of data bytes in S-record */
		    if (uart_read_u8(&len) == 0)
		      {
			cs = len;
			records++;
			switch(c)
			  {
			  case '0':
			    /* Header, skip first two bytes */
			    uart_read_u8(&dt);
			    uart_read_u8(&dt);
			    for (len -= 3; len; len--)
			      {
				if (uart_read_su8(&dt, &cs))
				  break;
				uart_txd(dt);
			      }
			    uart_read_u8(&dt);
			    break;
			  case '3':
			    /* Data record */
			    addr = 0;
			    for (i = 0; i < 4; i++)
			      {
				uart_read_su8(&dt, &cs);
				addr <<= 8;
				addr += (dt & 0x00ff);
			      }
			    pt = (char *) (addr + offset);
			    for (len -= 5; len; len--)
			      {
				if (uart_read_su8(&dt, &cs))
				  break;
				*(pt++) = dt;
			      }
			    uart_read_u8(&dt);
			    break;
			  case '7':
			    /* End of block record */
			    addr = 0;
			    for (len -= 1; len; len--)
			      {
				uart_read_su8(&dt, &cs);
				addr <<= 8;
				addr += (dt & 0x00ff);				
			      }
			    x = (uint32_t *) (addr + offset);
			    uart_read_u8(&dt);
			    break;
			  }
			if (dt != ((~cs) & 0x00ff))
			  {
			    uart_write_u32(cs);
			    uart_write_u32(dt);
			    cs_errs++;
			  }
		      }
		  }
	      }
	    while (c != '@');
	    uart_puts("\r\nRecords ");
	    uart_write_u32(records);
	    uart_puts("\r\nCS errs ");
	    uart_write_u32(cs_errs);
	  }
	  break;
	case 'M':
	  uart_puts("\r\n");
	  uart_write_u32(*x);
	  uart_puts(" ? ");
	  if (!uart_read_u32(&d))
	    *x = d;
	  break;
	case 'S':
	  c = uart_rxdU();
	  switch(c)
	    {
	    case 'S':
	      uart_txd(' ');
	      if (!uart_read_u32(&d))
		{
		  spi_slave_select(d);
		}
	      break;
	    case 'W':
	      uart_txd(' ');
	      if (!uart_read_u32(&d))
		{
		  d = spi_rw(d);
		  uart_txd(' ');
		  uart_write_u32(d);
		}
	      break;
  	    }
	  break;
	case 'V':
	  {
	    uint32_t records = 0;
	    uint32_t cs_errs = 0;
	    uint32_t dt_errs = 0;
	    uint32_t offset;

	    uart_txd(' ');
	    if(uart_read_u32(&offset))
	      break;
	    uart_puts("\r\nVerifying S-records... '@' to exit.\r\n");
	    do
	      {
		c = uart_rxd();
		if (c == 'S')
		  {
		    uint32_t cs;
		    uint32_t dt;
		    uint32_t len;
		    uint32_t addr;
		    char *pt;

		    c = uart_rxd();
		    /* Read number of data bytes in S-record */
		    if (uart_read_u8(&len) == 0)
		      {
			cs = len;
			records++;
			switch(c)
			  {
			  case '0':
			    /* Header, skip first two bytes */
			    uart_read_u8(&dt);
			    uart_read_u8(&dt);
			    for (len -= 3; len; len--)
			      {
				if (uart_read_su8(&dt, &cs))
				  break;
				uart_txd(dt);
			      }
			    uart_read_u8(&dt);
			    break;
			  case '3':
			    /* Data record */
			    addr = 0;
			    for (i = 0; i < 4; i++)
			      {
				uart_read_su8(&dt, &cs);
				addr <<= 8;
				addr += (dt & 0x00ff);
			      }
			    pt = (char *) (addr + offset);
			    for (len -= 5; len; len--)
			      {
				if (uart_read_su8(&dt, &cs))
				  break;
				if ((*(pt++) & 0x00ff) != dt)
				  dt_errs++;
			      }
			    uart_read_u8(&dt);
			    break;
			  case '7':
			    /* End of block record */
			    addr = 0;
			    for (len -= 1; len; len--)
			      {
				uart_read_su8(&dt, &cs);
				addr <<= 8;
				addr += (dt & 0x00ff);				
			      }
			    x = (uint32_t *) (addr + offset);
			    uart_read_u8(&dt);
			    break;
			  }
			if (dt != ((~cs) & 0x00ff))
			  {
			    uart_write_u32(cs);
			    uart_write_u32(dt);
			    cs_errs++;
			  }
		      }
		  }
	      }
	    while (c != '@');
	    uart_puts("\r\nRecords ");
	    uart_write_u32(records);
	    uart_puts("\r\nCS errs ");
	    uart_write_u32(cs_errs);
	    uart_puts("\r\nVF errs ");
	    uart_write_u32(dt_errs);
	  }
	  break;
	case 'X':
	  uart_txd(' ');
	  uart_read_u32((unsigned int *) &x);
	  break;
	default:
	  break;
	}
    }
}

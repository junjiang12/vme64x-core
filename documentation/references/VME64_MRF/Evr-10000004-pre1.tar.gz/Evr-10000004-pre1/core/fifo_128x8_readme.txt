The following files were generated for 'fifo_128x8' in directory 
D:\tmp\test\fifo\coregen\:

fifo_128x8.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

fifo_128x8.edn:
   Electronic Data Netlist (EDN) file containing the information
   required to implement the module in a Xilinx (R) FPGA.

fifo_128x8.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

fifo_128x8_fifo_generator_v2_3_xst_1_blkmemdp_v6_2_xst.ngo:
   Please see the core data sheet.

fifo_128x8_fifo_generator_v2_3_xst_1.ngc:
   Binary Xilinx implementation netlist. The logic implementation of
   certain CORE Generator IP is described by a combination of a top
   level EDN file plus one or more NGC files.

fifo_128x8.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

fifo_128x8.sym:
   Please see the core data sheet.

fifo_128x8.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

fifo_128x8_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

fifo_128x8_readme.txt:
   Text file indicating the files generated and how they are used.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.


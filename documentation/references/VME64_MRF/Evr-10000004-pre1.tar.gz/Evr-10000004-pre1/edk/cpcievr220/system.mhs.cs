

 PARAMETER VERSION = 2.1.0


 PORT sys_clk = sys_clk_s, DIR = I, SIGIS = CLK
 PORT sys_rst = sys_rst_s, DIR = I
 PORT opb_m_0_OPB_Clk = opb_m_wrapper_0_u_OPB_Clk, DIR = O, SIGIS = CLK
 PORT opb_m_0_OPB_Rst = opb_m_wrapper_0_u_OPB_Rst, DIR = O, SIGIS = Rst
 PORT opb_m_0_M_DBus = opb_m_wrapper_0_u_M_DBus, VEC = [0:31], DIR = I
 PORT opb_m_0_OPB_DBus = opb_m_wrapper_0_u_OPB_DBus, VEC = [0:31], DIR = O
 PORT opb_m_0_M_ABus = opb_m_wrapper_0_u_M_ABus, VEC = [0:31], DIR = I
 PORT opb_m_0_M_BE = opb_m_wrapper_0_u_M_BE, VEC = [0:3], DIR = I
 PORT opb_m_0_M_busLock = opb_m_wrapper_0_u_M_busLock, DIR = I
 PORT opb_m_0_M_request = opb_m_wrapper_0_u_M_request, DIR = I
 PORT opb_m_0_M_RNW = opb_m_wrapper_0_u_M_RNW, DIR = I
 PORT opb_m_0_M_select = opb_m_wrapper_0_u_M_select, DIR = I
 PORT opb_m_0_M_seqAddr = opb_m_wrapper_0_u_M_seqAddr, DIR = I
 PORT opb_m_0_OPB_errAck = opb_m_wrapper_0_u_OPB_errAck, DIR = O
 PORT opb_m_0_OPB_MGrant = opb_m_wrapper_0_u_OPB_MGrant, DIR = O
 PORT opb_m_0_OPB_retry = opb_m_wrapper_0_u_OPB_retry, DIR = O
 PORT opb_m_0_OPB_timeout = opb_m_wrapper_0_u_OPB_timeout, DIR = O
 PORT opb_m_0_OPB_xferAck = opb_m_wrapper_0_u_OPB_xferAck, DIR = O
 PORT opb_s_1_OPB_Clk = opb_s_wrapper_1_u_OPB_Clk, DIR = O, SIGIS = CLK
 PORT opb_s_1_OPB_Rst = opb_s_wrapper_1_u_OPB_Rst, DIR = O, SIGIS = Rst
 PORT opb_s_1_Sl_DBus = opb_s_wrapper_1_u_Sl_DBus, VEC = [0:31], DIR = I
 PORT opb_s_1_Sl_errAck = opb_s_wrapper_1_u_Sl_errAck, DIR = I
 PORT opb_s_1_Sl_retry = opb_s_wrapper_1_u_Sl_retry, DIR = I
 PORT opb_s_1_Sl_toutSup = opb_s_wrapper_1_u_Sl_toutSup, DIR = I
 PORT opb_s_1_Sl_xferAck = opb_s_wrapper_1_u_Sl_xferAck, DIR = I
 PORT opb_s_1_OPB_ABus = opb_s_wrapper_1_u_OPB_ABus, VEC = [0:31], DIR = O
 PORT opb_s_1_OPB_BE = opb_s_wrapper_1_u_OPB_BE, VEC = [0:3], DIR = O
 PORT opb_s_1_OPB_DBus = opb_s_wrapper_1_u_OPB_DBus, VEC = [0:31], DIR = O
 PORT opb_s_1_OPB_RNW = opb_s_wrapper_1_u_OPB_RNW, DIR = O
 PORT opb_s_1_OPB_select = opb_s_wrapper_1_u_OPB_select, DIR = O
 PORT opb_s_1_OPB_seqAddr = opb_s_wrapper_1_u_OPB_seqAddr, DIR = O
 PORT chipscope_opb_iba_0_iba_trig_in_pin = chipscope_opb_iba_0_iba_trig_in, DIR = I, VEC = [39:0]
BEGIN opb_v20
 PARAMETER INSTANCE = opb_v20_0
 PARAMETER HW_VER = 1.10.c
 PORT OPB_Clk = sys_clk_s
 PORT SYS_Rst = sys_rst_s
END

BEGIN opb_m_wrapper
 PARAMETER INSTANCE = opb_m_wrapper_1
 PARAMETER HW_VER = 1.00.a
 BUS_INTERFACE MOPB = opb_v20_0
 PORT u_OPB_Clk = opb_m_wrapper_0_u_OPB_Clk
 PORT u_OPB_Rst = opb_m_wrapper_0_u_OPB_Rst
 PORT u_M_DBus = opb_m_wrapper_0_u_M_DBus
 PORT u_OPB_DBus = opb_m_wrapper_0_u_OPB_DBus
 PORT u_M_ABus = opb_m_wrapper_0_u_M_ABus
 PORT u_M_BE = opb_m_wrapper_0_u_M_BE
 PORT u_M_busLock = opb_m_wrapper_0_u_M_busLock
 PORT u_M_request = opb_m_wrapper_0_u_M_request
 PORT u_M_RNW = opb_m_wrapper_0_u_M_RNW
 PORT u_M_select = opb_m_wrapper_0_u_M_select
 PORT u_M_seqAddr = opb_m_wrapper_0_u_M_seqAddr
 PORT u_OPB_errAck = opb_m_wrapper_0_u_OPB_errAck
 PORT u_OPB_MGrant = opb_m_wrapper_0_u_OPB_MGrant
 PORT u_OPB_retry = opb_m_wrapper_0_u_OPB_retry
 PORT u_OPB_timeout = opb_m_wrapper_0_u_OPB_timeout
 PORT u_OPB_xferAck = opb_m_wrapper_0_u_OPB_xferAck
 PORT OPB_Clk = sys_clk_s
END

BEGIN opb_s_wrapper
 PARAMETER INSTANCE = opb_s_wrapper_2
 PARAMETER HW_VER = 1.00.a
 BUS_INTERFACE SOPB = opb_v20_0
 PORT u_OPB_Clk = opb_s_wrapper_1_u_OPB_Clk
 PORT u_OPB_Rst = opb_s_wrapper_1_u_OPB_Rst
 PORT u_Sl_DBus = opb_s_wrapper_1_u_Sl_DBus
 PORT u_Sl_errAck = opb_s_wrapper_1_u_Sl_errAck
 PORT u_Sl_retry = opb_s_wrapper_1_u_Sl_retry
 PORT u_Sl_toutSup = opb_s_wrapper_1_u_Sl_toutSup
 PORT u_Sl_xferAck = opb_s_wrapper_1_u_Sl_xferAck
 PORT u_OPB_ABus = opb_s_wrapper_1_u_OPB_ABus
 PORT u_OPB_BE = opb_s_wrapper_1_u_OPB_BE
 PORT u_OPB_DBus = opb_s_wrapper_1_u_OPB_DBus
 PORT u_OPB_RNW = opb_s_wrapper_1_u_OPB_RNW
 PORT u_OPB_select = opb_s_wrapper_1_u_OPB_select
 PORT u_OPB_seqAddr = opb_s_wrapper_1_u_OPB_seqAddr
 PORT OPB_Clk = sys_clk_s
END

BEGIN chipscope_icon
 PARAMETER INSTANCE = chipscope_icon_0
 PARAMETER HW_VER = 1.01.a
 PORT control0 = chipscope_icon_0_control0
END

BEGIN chipscope_opb_iba
 PARAMETER INSTANCE = chipscope_opb_iba_0
 PARAMETER HW_VER = 1.01.a
 PARAMETER C_ENABLE_TRIGGER_OUT = 0
 PARAMETER C_MAX_SEQUENCER_LEVELS = 1
 PARAMETER C_ADDR_UNITS = 1
 PARAMETER C_DATA_UNITS = 1
 PARAMETER C_GENERIC_TRIGGER_UNITS = 1
 PARAMETER C_TRIGGER_UNIT_MATCH_TYPE = basic
 PARAMETER C_GENERIC_TRIGGER_IN_WIDTH = 40
 PARAMETER C_PV_UNITS = 1
 PARAMETER C_MASTER0_UNITS = 1
 BUS_INTERFACE MON_OPB = opb_v20_0
 PORT SYS_Rst = sys_rst_s
 PORT chipscope_icon_control = chipscope_icon_0_control0
 PORT iba_trig_in = chipscope_opb_iba_0_iba_trig_in
END

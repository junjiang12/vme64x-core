The following files were generated for 'icon1' in directory 
/mnt/nfs/home/mirror/mrf/event/fw/Evr/trunk/core_v5/

icon1_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

icon1.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

icon1.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

icon1.ise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

icon1.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

icon1.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

icon1.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

icon1.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

icon1.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

icon1_readme.txt:
   Text file indicating the files generated and how they are used.

icon1_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

